import java.util.ArrayList;
import java.util.Scanner;

public class SolitaireEncryption {

    public static char encryptChar(char letter, int key) {
        int value =   letter - 'a';
        int encryptedValue =  (value + key) % 26;
        char encryptedChar = (char) (encryptedValue+'a');

        return encryptedChar;
    }


    public static char decryptChar(char letter, int key) {
        int value =   letter - 'a';
        int decryptedValue =  (value + (26-key)) % 26;
        char decryptedChar = (char) (decryptedValue+'a');

        return decryptedChar;
    }

    public int getKey(CircularLinkedList<Integer> deck){ // calls the steps methods
        return -1;
    }

    private static void step1(CircularLinkedList<Integer> deck){
        for (int i = 0; i < deck.size; i++) {
            if(deck.get(i) == 27){
                if(i+1 > 28){
                    i = (i+1)-28;
                }
                deck.add(i+1,deck.get(i));
                deck.remove(i);
            }
        }
    }

    private static void step2(CircularLinkedList<Integer> deck){
        for (int i = 0; i < deck.size; i++) {
            if(deck.get(i)==28){
                if(i+2 > 28){
                    i = (i+2)-28;
                }
                deck.add(i+2,deck.get(i));
                deck.remove(i);
            }
        }
    }
    private static void step3(CircularLinkedList<Integer> deck){

    }
    private static void step4(CircularLinkedList<Integer> deck){

    }
    private static int step5(CircularLinkedList<Integer> deck){
        return -1;
    }

    public static void main(String[] args) {
//        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
//        boolean loop = true;
//        ArrayList <String> listOfMessages = new ArrayList<>();
//        System.out.println("Enter a message to decrypt or type quit to exit: ");
//
//        while(loop) {
//            String message = myObj.nextLine();  // Read user input
//            if(message.equals("quit")){
//                loop = false;
//            }
//            else{
//                listOfMessages.add(message);
//            }
//        }


        CircularLinkedList<Integer> deck = new CircularLinkedList<>();
        int ShuffledDeck[] = {14, 22, 5, 3, 9, 16, 10, 2, 25, 21, 17, 6, 18, 28, 24, 4, 13, 1, 12, 20, 19, 8, 26, 11, 7, 23, 27, 15};
        for(int i = 0; i < ShuffledDeck.length; i++) {
            deck.add(ShuffledDeck[i]);
        }
        System.out.println(deck);
        step1(deck);
        System.out.println(deck);


    }
}
