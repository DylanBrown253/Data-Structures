//credit : https://www.codepile.net/pile/ydJRPXd2 coding with John
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class InsertionSort {
    public static int swaps = 0;
    public static int comparisons = 0;

    public static void main(String[] args) {
        int count = 0;
        int averageTime = 0;
        int averageSwaps = 0;
        int averageComparisons = 0;
        StringBuilder fileString = new StringBuilder();

        for (int j = 0; j < 10; j++) {

            Random rand = new Random();
            int[] numbers = new int[10000];

            swaps = 0;
            comparisons = 0;

            for (int i = 0; i < numbers.length; i++) {
                numbers[i] = rand.nextInt(100);
            }

            //System.out.println("Before:");
            //printArray(numbers);

            long startTime = System.nanoTime();
            insertionSort(numbers);
            long estimatedTime = System.nanoTime() - startTime;
            count++;
            //System.out.println("\nAfter:");
            //printArray(numbers);
            averageTime += estimatedTime;
            averageComparisons += comparisons;
            averageSwaps += swaps;

            fileString.append("\n" + "Array" + count + "," + "Estimated time, " + estimatedTime
                    + ",Number of swaps, " + swaps
                    + ",Number of comparisons, " + comparisons + '\n');

        }
        averageTime = averageTime/10;
        averageSwaps = averageSwaps/10;
        averageComparisons = averageComparisons/10;
        StringBuilder averages = new StringBuilder();
        averages.append("Insertion Sort," + "Average Time " + ","  + averageTime + "," +"Average swaps"  + "," + averageSwaps +   "," + "Average comparisons"  + "," + averageComparisons);


        try {
            FileWriter myWriter = new FileWriter("InsertionSort.csv");
            //myWriter.write(String.valueOf(fileString));
            myWriter.write(String.valueOf(averages));
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

    }
    private static void insertionSort(int[] inputArray) {
        for (int i = 1; i < inputArray.length; i++) {
            int currentValue = inputArray[i];

            int j = i - 1;
            while (j >= 0 && inputArray[j] > currentValue) {
                comparisons++;

                inputArray[j + 1] = inputArray[j];
                swaps++;
                j--;
            }
            inputArray[j + 1] = currentValue;
            swaps++;
        }
    }

    private static void printArray(int[] numbers) {
        for (int i = 0; i < numbers.length; i++) {
            System.out.println(numbers[i]);
        }
    }


}
