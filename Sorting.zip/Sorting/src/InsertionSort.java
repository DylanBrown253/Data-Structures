import java.util.Arrays;

public class InsertionSort {
    public static void main(String[] args) {
        int[] array = {20,5,90,30,1,3,21,4};
        insertionSort(array);
        System.out.println(Arrays.toString(array));
    }
    public static void insertionSort(int[] array){
        long startTime = System.nanoTime();
        int j;
        int swaps = 0;
        int comparisons = 0;
        for (int i = 1; i < array.length; i++) {
            j = i;
            while(j>0 && array[j-1] > array[j]){
                swap(array,j);
                swaps++;
                j = j - 1;
            }
            comparisons++;
        }
        long estimatedTime = System.nanoTime() - startTime;
        System.out.println("Time " + estimatedTime);
        System.out.println("Comparisons = " + comparisons + "\nSwaps = "+ swaps);
    }
    private static void swap(int[] array, int j) {
        int temp = array[j];
        array[j] = array[j-1];
        array[j-1] = temp;
    }
}
