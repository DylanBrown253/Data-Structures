import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;

//CREDIT : https://www.codepile.net/pile/X6lXog6G coding with john

public class QuickSort {
    public static int swaps = 0;
    public static int comparisons = 0;

    public static void main(String[] args) {
        int count = 0;
        int averageTime = 0;
        int averageSwaps = 0;
        int averageComparisons = 0;
        StringBuilder fileString = new StringBuilder();
        for (int j = 0; j < 10; j++) {
            swaps = 0;
            comparisons = 0;


            Random rand = new Random();
            int[] numbers = new int[10000];

            for (int i = 0; i < numbers.length; i++) {
                numbers[i] = rand.nextInt(100);
            }

            //System.out.println("Before:");
            //printArray(numbers);

            long startTime = System.nanoTime();
            quicksort(numbers);
            long estimatedTime = System.nanoTime() - startTime;

            //System.out.println("\nAfter:");
            //printArray(numbers);
            count++;

//            fileString.append("\n" + "Array" + count + "," + "Estimated time, " + estimatedTime
//                    + ",Number of swaps, " + swaps
//                    + ",Number of comparisons, " + comparisons + '\n');
            averageTime += estimatedTime;
            averageComparisons += comparisons;
            averageSwaps += swaps;
        }
        averageTime = averageTime/10;
        averageSwaps = averageSwaps/10;
        averageComparisons = averageComparisons/10;
        StringBuilder averages = new StringBuilder();
        averages.append("Quick Sort," + "Average Time " + ","  + averageTime + "," +"Average swaps"  + "," + averageSwaps +   "," + "Average comparisons"  + "," + averageComparisons);

        try {
            FileWriter myWriter = new FileWriter("QuickSort.csv");
            //myWriter.write(String.valueOf(fileString));
            myWriter.write(String.valueOf(averages));
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    private static void quicksort(int[] array) {
        quicksort(array, 0, array.length - 1);
    }
    private static void quicksort(int[] array, int lowIndex, int highIndex){
        if(lowIndex >= highIndex){
            return;
        }
        int pivotIndex = new Random().nextInt(highIndex - lowIndex) + lowIndex;

        int pivot = array[pivotIndex];
        swap(array, pivotIndex, highIndex);



        int leftPointer = partition(array, lowIndex, highIndex, pivot);


        quicksort(array,lowIndex,leftPointer-1);
        quicksort(array,leftPointer+1,highIndex);
    }
    private static void swap(int[] array, int index1, int index2){
        int temp = array[index1];
        array[index1] = array[index2];
        array[index2] = temp;
        swaps++;
    }
    private static int partition(int[] array, int lowIndex, int highIndex, int pivot){
        int leftPointer = lowIndex;
        int rightPointer = highIndex;

        while(leftPointer < rightPointer){
            comparisons++;
            while(array[leftPointer] <= pivot && leftPointer < rightPointer){
                leftPointer++;
            }
            comparisons++;
            while(array[rightPointer] >= pivot && leftPointer < rightPointer){
                rightPointer--;
            }
            swap(array, leftPointer, rightPointer);
        }
        swap(array, leftPointer, highIndex);
        return leftPointer;
    }
    private static void printArray(int[] numbers) {
        for (int i = 0; i < numbers.length; i++) {
            System.out.println(numbers[i]);
        }
    }

}
