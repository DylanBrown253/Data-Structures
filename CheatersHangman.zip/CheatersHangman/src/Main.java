import java.io.FileNotFoundException;
import java.util.*;
import java.io.File;  // Import the File class
import java.util.ArrayList;
public class Main {
    public static void main(String[] args)throws FileNotFoundException {
        String reply = "y";
        while(reply.equals("y")) {
            HashMap<Integer, List<String>> wordList = new HashMap<>();
            wordList.putAll(genWordList());
            Scanner scanner = new Scanner(System.in);
            System.out.println("\tHow many letters do you want to play with? ");
            int letterCount = scanner.nextInt();
            while (!wordList.containsKey(letterCount)) {
                System.out.println("\tThere are no words of this size");
                System.out.println("\tTry again how many letters do you want to play with? ");
                letterCount = scanner.nextInt();
            }
            int numGuesses = wrongGuesses();
            game(wordList.get(letterCount), numGuesses);

            //get input to play again
            Scanner myReader = new Scanner(System.in);
            System.out.println("Do you wanna play again (y/n)");
            reply = myReader.next();
        }

    }
    public static void game(List<String> wordList, int guesses){
        System.out.println("========================================Your Hangman Board========================================");
        Set<Character> guessedSet = new HashSet<>();

        String bestFamKey = "";
        ArrayList<String> bestFam = new ArrayList<>(wordList);
        boolean won = false;
        for (int i = 0; i < wordList.get(0).length(); i++) {
            System.out.print('_');
        }
        for (int i = 0; i < guesses && won == false; i++) {
            System.out.println("\nNumber of guesses: " + i);
            System.out.println("Guesses Remaining: " + (guesses - i));

            Scanner scanner = new Scanner(System.in);
            System.out.println("Make a guess: ");
            String user_guess = scanner.next();
            for (int j = 0; j < user_guess.length(); j++) {
                System.out.println(user_guess.charAt(j));
                guessedSet.add(user_guess.charAt(j));
            }
            HashMap<String, ArrayList<String>> families = new HashMap<>();
            families.putAll(createWordFamilies(bestFam, guessedSet));
            String oldBestFamKey = bestFamKey;
            bestFamKey = getBestFamily(families);
            bestFam.clear();
            bestFam.addAll(families.get(bestFamKey));
            System.out.println(bestFamKey);
            if(!same(oldBestFamKey,bestFamKey,i)){
                i--;
            }
            if (!bestFamKey.contains("_")) {
                won = true;
                if(won == true){
                    System.out.println("Wow you actually won i'm shocked great job!");
                }
            }
            if (i == guesses -1) {
                Random rand = new Random();
                int randNum = rand.nextInt(bestFam.size());
                System.out.println("you lost!");
                System.out.println("I was thinking of: " + bestFam.get(randNum));
            }
        }
    }
    public static boolean same(String oldBestFamKey, String bestFamKey, int index){
        if(!oldBestFamKey.equals(bestFamKey) && index != 0){
            return false;
        }

        else return true;
    }
    public static HashMap<Integer, List<String>>  genWordList() throws FileNotFoundException {
        HashMap<Integer, List<String>> wordsBySize = new HashMap<>();
        Scanner fileScanner = new Scanner(new File("C:\\Users\\Fish1\\Java-workspace\\CheatersHangman\\words.txt"));
        while(fileScanner.hasNextLine()){
            String word = fileScanner.nextLine().toLowerCase();
            if(wordsBySize.containsKey(word.length())){
                wordsBySize.get(word.length()).add(word);
            }
            else{
                List<String> list = new ArrayList<>();
                list.add(word);
                wordsBySize.put(word.length(), list);
            }
        }
        return wordsBySize;
    }
    public static Map<String, ArrayList<String>> createWordFamilies(List<String> words, Set<Character> guessed){
        HashMap<String, ArrayList<String>> families = new HashMap<>();

        for (String word: words) {
            String key = "";
            for (int i = 0; i < word.length(); i++) {
                if (guessed.contains(word.charAt(i))) {
                    key += word.charAt(i);
                } else {
                    key += '_';
                }
            }
            if (!families.containsKey(key)) {
                ArrayList<String> familyList = new ArrayList<>();
                familyList.add(word);
                families.put(key, familyList);
            } else {
                families.get(key).add(word);
            }
        }
        return families;
    }
    public static String getBestFamily(Map<String, ArrayList<String>> wordFamilies){
        ArrayList<String> biggestFamily = new ArrayList<>();
        String key = "";
        for(Map.Entry<String, ArrayList<String>> set : wordFamilies.entrySet()){
            if(set.getValue().size() > biggestFamily.size()){
                biggestFamily.addAll(set.getValue());
                key = set.getKey();
            }
        }
        return key;
    }
    public static int wrongGuesses(){
        Scanner scanner  = new Scanner(System.in);
        System.out.println("\tHow many wrong guesses should we give you");
        int wrongGuesses = scanner.nextInt();
        return wrongGuesses;
    }

}